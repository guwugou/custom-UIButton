//
//  GZView.h
//  Picture
//
//  Created by demo on 16/1/21.
//  Copyright © 2016年 GuZhiQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GZView : UIView

@end
