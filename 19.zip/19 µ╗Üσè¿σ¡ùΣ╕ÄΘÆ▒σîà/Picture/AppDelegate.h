//
//  AppDelegate.h
//  Picture
//
//  Created by demo on 15/12/29.
//  Copyright © 2015年 GuZhiQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

